# 🥗 Healthy Meal Classifier

This application is a simple, interactive tool that helps users classify meals as **Healthy**, **Unhealthy**, or **Neutral** based on the ingredients they provide. It is developed entirely in Python and runs directly within Jupyter Notebook using `ipywidgets` for a smooth interactive experience.

---

## 📖 Features
- Interactive ingredient input using widgets.
- Real-time meal classification.
- User-friendly interface within Jupyter Notebook.
- No external datasets required — uses predefined knowledge-based rules.

---

## 🚀 How to Run

1. Open the provided `.ipynb` file in Jupyter Notebook.
2. Run all cells to activate the application.
3. Enter a list of ingredients separated by commas (e.g., `broccoli, fries, apple`).
4. Click the **Classify Meal** button to view the result.

---

## 📹 Demo Video
[Watch the demo on Panopto](https://slu.hosted.panopto.com/Panopto/Pages/Viewer.aspx?id=de4d29d2-69d7-4e05-aafd-b2ca004a7016)

---

## 👩‍💻 Developed By
- Arati Gohil

*This project was developed as part of the Arch Data Network Innovation Showcase.*

---

© 2025 Healthy Meal Classifier. All rights reserved.
