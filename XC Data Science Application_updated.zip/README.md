# 🥗 Healthy Meal Classifier  

This application is an interactive tool that classifies meals as **Healthy**, **Unhealthy**, or **Neutral** based on the ingredients provided by the user. It is developed entirely in Python and runs directly within Jupyter Notebook using `ipywidgets` for a smooth interactive experience.

---

## 📖 Features  
- Interactive ingredient input using widgets.  
- Real-time meal classification using a **Logistic Regression machine learning model**.  
- User-friendly interface within Jupyter Notebook.  
- Simple and quick predictions based on trained model data.

---

## 📊 Data Science Model  

- **Model Type:** Logistic Regression  
- **Training Data:** A synthetic dataset representing common healthy, unhealthy, and neutral meals.  
- **Model Pipeline:**  
  - Ingredient text is vectorized using `CountVectorizer`.  
  - The Logistic Regression classifier predicts the meal category.  
- **Model File:** `meal_classifier_model.pkl` (Ensure this file is in the same directory as the notebook.)

---

## 🚀 How to Run  

1. Open the provided `.ipynb` file in Jupyter Notebook.  
2. Ensure `meal_classifier_model.pkl` is in the same directory.  
3. Run all cells to activate the application.  
4. Enter a list of ingredients separated by commas (e.g., `broccoli, fries, apple`).  
5. Click the **Classify Meal** button to view the result.

---

## 📹 Demo Video  
[Watch the demo on Panopto](https://slu.hosted.panopto.com/Panopto/Pages/Viewer.aspx?id=de4d29d2-69d7-4e05-aafd-b2ca004a7016)  

---
## 📂 Project Repository  
[View the full project on GitHub](https://github.com/Arati-Gohil3298/HDS-Data.git)

## 👩‍💻 Developed By  
- Arati Gohil  

© 2025 Healthy Meal Classifier. All rights reserved.
